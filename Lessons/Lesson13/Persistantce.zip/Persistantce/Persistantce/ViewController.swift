//
//  ViewController.swift
//  Persistantce
//
//  Created by Angel S. Moreno on 2/18/15.
//  Copyright (c) 2015 Angel S. Moreno. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    var athletes: [String]?
    let defaultAthletes = [
        "Bo Jackson",
        "Michael Jordan",
        "Babe Ruth"
    ]
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        if let athletes = NSUserDefaults.standardUserDefaults().arrayForKey("athletes") as? [String] {
            self.athletes = athletes
        } else {
            self.athletes = self.defaultAthletes
            NSUserDefaults.standardUserDefaults().setObject(self.athletes, forKey: "athletes")
        }
        printNames()
        
    }

    func printNames(){
        println(self.athletes)
//        if let athletes = self.athletes {
//            for name in athletes {
//                println(name)
//            }
//        }
        
    }
}

